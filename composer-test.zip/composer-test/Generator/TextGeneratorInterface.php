<?php 

  interface TextGeneratorInterface
  {
  	 public function generate(int $length=10 ): string;
  } 
